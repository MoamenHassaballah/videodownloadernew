
package avd.downloader;

public interface PermissionRequestCodes {
    int DOWNLOADS = 4444;
}
