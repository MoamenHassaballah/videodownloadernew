
package avd.downloader.history_feature;

public class VisitedPage {
    public String title;
    public String link;
}
