

package avd.downloader.bookmarks_feature;

import android.graphics.Bitmap;

public class Bookmark {
    public Bitmap icon;
    public String title;
    public String url;
}
