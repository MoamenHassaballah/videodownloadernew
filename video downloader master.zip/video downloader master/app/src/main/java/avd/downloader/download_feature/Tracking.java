
package avd.downloader.download_feature;

public interface Tracking {
    void startTracking();

    void stopTracking();
}
